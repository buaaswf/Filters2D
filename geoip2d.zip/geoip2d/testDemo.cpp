#ifndef SWF_RAW2D_FILTERS
#define SWF_RAW2D_FILTERS
#include <stdio.h>

//#include "CImg.h"
//#include "test.h"
#include <assert.h>
#include "vol_math_2D_filter_interface.h"
#include <stdio.h>
#include <tchar.h>
#define CRTDBG_MAP_ALLOC
#include <stdlib.h>
#include <crtdbg.h>
#include "KDetectMemoryLeak.h"

#endif